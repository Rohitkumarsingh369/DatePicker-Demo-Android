package com.example.datepickerdemo;

import androidx.appcompat.app.AppCompatActivity;

import android.app.DatePickerDialog;
import android.os.Bundle;
import android.view.View;
import android.widget.DatePicker;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.Calendar;

public class MainActivity extends AppCompatActivity {
    TextView tvdob,tvage;
    int difference;
    ImageView cal;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        tvdob=findViewById(R.id.textView4);
        tvage=findViewById(R.id.textView5);
        cal=findViewById(R.id.imageView);
    }
    public void displaydob(View view){
        final Calendar c=Calendar.getInstance();
        final int mYear=c.get(Calendar.YEAR);
        final int mMonth=c.get(Calendar.MONTH);
        final int mDate=c.get(Calendar.DATE);
        DatePickerDialog datePickerDialog=new DatePickerDialog(MainActivity.this, android.R.style.Theme_DeviceDefault_DialogWhenLarge, new DatePickerDialog.OnDateSetListener() {
            @Override
            public void onDateSet(DatePicker view, int year, int month, int dayofmonth) {
                tvdob.setText(dayofmonth+"/"+(month+1)+"/"+year);
                difference=mYear-year;
            }
        },mYear,mMonth,mDate);
        datePickerDialog.show();
    }
    public void showmyage(View view){
        if(difference!=0) {
            tvage.setText("Age :" + difference);
        }
        else{
            Toast.makeText(this, "Please enter the age", Toast.LENGTH_SHORT).show();
        }
    }
}